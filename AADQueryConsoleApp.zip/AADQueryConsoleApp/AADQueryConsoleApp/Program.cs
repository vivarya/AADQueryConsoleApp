﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Globalization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace AADQueryConsoleApp
{
    class Program
    {
 
        private const string clientId = "e70865b8-f287-4871-80d2-7f4321773a7b";
        private const string aadInstance = "https://login.microsoftonline.com/{0}";
        private const string tenant = "vivekaryainc.onmicrosoft.com";
        private const string appKey = "xh?2]S0Hi-7vOZrNBNy5Irzz?@VyPNKH";

        private const string resource = "https://graph.microsoft.com";

        static string authority = String.Format(CultureInfo.InvariantCulture, aadInstance, tenant);

        private static HttpClient httpClient = new HttpClient();
        private static AuthenticationContext context = null;
        private static ClientCredential credential = null;
        static void Main(string[] args)
        {
            context = new AuthenticationContext(authority);
            credential = new ClientCredential(clientId, appKey);

            Task<string> token = GetToken();
            token.Wait();
            Console.WriteLine("Here is the token: " + "\n");
            Console.WriteLine(token.Result + "\n");
            Console.WriteLine("-------------------------------------------------");

            Task<string> users = GetUsers(token.Result);
            users.Wait();

            Console.WriteLine("Here are the Users: " + "\n");
            Console.WriteLine(users.Result);
            Console.WriteLine("-------------------------------------------------");

            Console.ReadLine();
        }

        private static async Task<string> GetUsers(string result)
        {
            string users = null;
            var uri = "https://graph.microsoft.com/v1.0/users?";
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", result);
            var userResult = await httpClient.GetAsync(uri);

            if( userResult != null)
            {
                users = await userResult.Content.ReadAsStringAsync();
            }
            return users;
        }
       
        private static async Task<string> GetToken()
        {
            AuthenticationResult result = null;
            string token = null;
            result = await context.AcquireTokenAsync(resource, credential);
            token = result.AccessToken;
            return token;
        }
    }
}

